// Global navigation function
function goToDashboard() {
  window.location.href = "pages/dashboard.html";
}

// Dashboard navigation helper
function navigate(page) {
  // Ensure page path resolves relative to dashboard
  window.location.href = page;
}

// AI Hub: send message to backend (placeholder)
async function askAI() {
  const input = document.getElementById('ai-message');
  const responseEl = document.getElementById('ai-response');
  const message = input.value.trim();
  if (!message) {
    responseEl.innerText = 'Please enter a question.';
    return;
  }
  responseEl.innerText = 'Thinking…';
  try {
    // Replace this URL with your cloud function or API endpoint
    const url = 'https://your-backend.example.com/api/ai?msg=' + encodeURIComponent(message);
    const res = await fetch(url);
    if (!res.ok) throw new Error('Network response was not ok');
    const data = await res.json();
    responseEl.innerText = data.response || 'No response from AI.';
  } catch (err) {
    console.error(err);
    responseEl.innerText = 'Error communicating with AI service.';
  }
}

// Scan Malware: upload and handle file (placeholder)
async function scanFile() {
  const fileInput = document.getElementById('malware-file');
  const resultEl = document.getElementById('scan-result');
  if (!fileInput.files.length) {
    resultEl.innerText = 'Select a file to scan.';
    return;
  }
  const file = fileInput.files[0];
  resultEl.innerText = 'Uploading and scanning…';
  try {
    // Upload to Firebase Storage via your backend (not implemented here)
    // Example: send to cloud function that writes file to Storage and triggers scanning extension
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch('https://your-backend.example.com/api/scan', {
      method: 'POST',
      body: formData
    });
    if (!res.ok) throw new Error('Upload failed');
    const data = await res.json();
    resultEl.innerText = data.message || 'Scan complete. No threats found.';
  } catch (err) {
    console.error(err);
    resultEl.innerText = 'Error during scan.';
  }
}